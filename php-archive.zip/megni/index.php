
<?php
  require "Includes/core.inc.php";
  
  $lang = "en";
  if (isset($_GET['lang'])) $lang = get('lang');
  if (isset($_GET['iaith'])) $lang = get('iaith');

  if ($lang=='cy') {
      $content = view("Views/pages/cy.php",array());
  } else {
      $content = view("Views/pages/main.php",array());
  }

  print view("Views/theme/theme.php", array('content'=>$content));

?>



