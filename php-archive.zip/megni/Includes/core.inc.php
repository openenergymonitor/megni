<?php
  /*
   All Emoncms code is released under the GNU General Public License v3.
   See COPYRIGHT.txt and LICENSE.txt.

    ---------------------------------------------------------------------
    Emoncms - open source energy visualisation
    Part of the OpenEnergyMonitor project:
    http://openenergymonitor.org
  */
  function controller($cat)
  {
    $controller = $cat."_controller";
    $controllerScript = "Controllers/".$controller.".php";

    if (is_file($controllerScript))
    {
      require $controllerScript;
      $content = $controller();
    }

    return $content;
  }
  
function get($index)
{
    $val = null;
    if (isset($_GET[$index])) $val = $_GET[$index];
    
    if (get_magic_quotes_gpc()) $val = stripslashes($val);
    return $val;
}


  function view($filepath, array $args)
  {
    $viewScript = $filepath;
    if (is_file($viewScript))
    {
    extract($args);
    ob_start();       
    include $viewScript;   
    $content = ob_get_clean();   
    } 
    return $content;
  }
?>
