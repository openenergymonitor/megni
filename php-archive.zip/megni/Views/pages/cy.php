<?php

 $path = "https://megni.co.uk/";

?>
      <div id="header">
      
        <div id="title">Megni</div>
            <div id="maintext">
            Monitro Egni
                <div style="float:right">
                    <a href="?lang=en">English</a>
                </div>
            </div>

      </div>
      <div id="box">
        <div id="maintext">
          <img src="<?php echo $path; ?>Views/pages/images/snowdonia.jpg" style="width:930px; padding-top:20px"/>
          <p>Technoleg sydd yn helpu ni fyw o fewn terfynau ecolegol</p>
        </div>
      </div>
      <div id="box">
        <div id="maintext">
          <h1>System OpenEnergyMonitor</h1>
          <h2>Disgrifiad y system</h2>
          <img src="<?php echo $path; ?>Views/pages/images/system.png" style="float:right"/>
          <p>Mae system OpenEnergyMonitor yn system monitro egni hollol agored (open source) sydd yn gedru monitro trydan, temheredd, ac yn gedru cael ei cysylltu a dyfeisiau gyda allbwn pwls fel metrau dwr a trydan.</p>
          
          <p>Mae'r system wedi eu cynrychioli o pump prif darn: yr emonTx, emonTH, emonGLCD, emonBase a emoncms.</p>
          
          <p>Medrwch rhoi rhain gydai gilydd ac ei defnyddio I sawl gwahanol application, megis: monitro trydan cartref, monitro faint o egni sydd yn cael ei greu gan ffynhonnell adnewyddadwy fel paneli solar a mesur perfformiad gwres adeiladau.</p>
          
          <p>Mae meddalwedd a dyluniau chaledwedd y system yn hollol ffynhonnell agored, a mae gwybodaeth ar popeth o theori mesur pwer I sut mae'r cylched yn gweithio a sut mae'r meddalwedd yn gweithio ar gael ar y prif wefan: <a href="https://openenergymonitor.org/emon" >openenergymonitor.org</a></p>

          

        </div>
      </div>
      
      <div id="box">
        <div id="maintext">
          <h2>emonTx</h2>
          <img src="<?php echo $path; ?>Views/pages/images/emontx.jpg" style="float:left; width:350px; padding-right:20px; padding-bottom:20px;"/>
          
          <p>Yr emonTx ywr prif uned mesur ac mae fel arfer yn eistedd nesa ir metr trydan lle mae'r trydan yn dod I fewn ir adeilad. Mae yn mesur faint o drydan sydd yn cael ei defnyddio gyda synhwrydd sydd yn clippio mlaen ir wifren drydan, mae'r emontx hefyd yn mesur voltedd trydan gyda ACAC adapter. Mae hyn yn galleiogi mesur 'real power' a ffactor pwer yn ychwanegol I 'apparent power'. Mae posib pweru yr emontx or adapter neu o fatris.</p>
          
          <p>Yn ychwanegol I mesur trydan, mae'r emonTx yn gedru cael ei gysylltu a dyfeisiau gyda allbwn pwls fel metrau dwr a trydan. Mae ganddo hefyd mewnbwn mesur tymheredd synhwyrydd digidol DS18B20, a mae posib cysylltu nifer o rhain i'r un mewnbwn.</p>
          
          <p><b>emonTx: </b><a href="https://openenergymonitor.org/emon/modules/emonTxV3">Dogfennaeth</a>, <a href="https://shop.openenergymonitor.com/emontx-v3/" >Siop</a></p>
          
        </div>
      </div>

      <div id="box">
        <div id="maintext">
                <img src="<?php echo $path; ?>Views/pages/images/emonglcd.jpg" style="float:right; width:300px; padding-left:20px; padding-top:20px"/>
        <h2>emonGLCD</h2>

        <p>Sgrin bach yw yr EmonGLCD sydd wedi ei dylunio ar gyfer dangos gwybodaeth fel defnydd trydan yn yr eiliad hon mewn fordd lot haws na llwytho y wefan bob tro. Maint y sgrin yw 128px wrth 64px ac mae yn hollol programmable. Mae meddalwedd ar gael ar gyfer dangos maint o drydan sydd yn cael ei greu gan panelli haul yn gymharol ar maint o drydan sydd yn cael ei defnyddio mewn ty sydd yn un o prif defnydd y sgrin. Mae gan y sgrin LED's amgylchynol sydd yn gedru cael ei defnyddio ar gyfer indicaddio os oes mwy o drydan yn cael ei gynhyrchu nac yn cael ei ddefnyddio neu y ffordd arall rownd.</p>
        
        <p><i>Ar hyn o bryd mae'r EmonGLCD ar gael fel cit, mae angen cael ei rhoi efo'i gilydd gyda llaw iw defnyddio, mae creu versiwn sydd ddim angen ei adeiladu ar y gweill.</i></p>
        
<p><b>emonGLCD: </b><a href="https://openenergymonitor.org/emon/emonglcd">Dogfennaeth</a>, <a href="https://shop.openenergymonitor.com/displays/" >Siop</a></p>
        <div style="clear:both;"></div>
        </div>
      </div>
    
      <div id="box">
        <div id="maintext">
        <h2>emonTH</h2>
        <img src="<?php echo $path; ?>Views/pages/images/emonth.png" style="float:left; width: 400px; padding-right:20px"/>
        <p>Mae'r EmonTH wedi ei dylunio ar gyfer mesur performiad egni gwres mewn adeiladau. Mae yn mesur tymheredd a lleithder, mae yn nod di-wifr ac yn cael ei bweru gan ddau batri AA gyda cylched boost ar gyfer bywyd battris hir. Mae posib defnyddio synhwyrydd tymheredd DS18B20 neu synhwyrydd tymheredd a lleithder DHT22, mae hefyd posib cysylltu synhwyrydd tymheredd allanol.</p>
        <p><b>emonTH: </b><a href="https://openenergymonitor.org/emon/modules/emonTH">Dogfennaeth</a>, <a href="https://shop.openenergymonitor.com/temperature-humidity-nodes/" >Siop</a></p>
        <div style="clear:both;"></div>
        </div>
      </div>
      
      <div id="box">
        <div id="maintext">
                <img src="<?php echo $path; ?>Views/pages/images/raspberrypi.png" style="float:right; width: 200px; padding-left:20px"/>
        <h2>emonBase</h2>
        
        <p>EmonBase ywr uned sydd yn cysylltu y system ir we. Mae'n gyrru ymlaen y data sydd yn cael ei derbyn can y synwyryddion ir wefan emoncms sydd yn gwneud hin bosib i weld a archiwilior data drost amser. Mae hefyd bosib recordio data ar SD card EmonBase a edrych ar eich data heb ei gysylltu ar we-eang. Mae'r EmonBase wedi ei pweru gan RaspberryPI (y cyfrifiadur poblogaidd bach a cost isel yn rhedeg Linux).

        <p><b>emonBase: </b><a href="https://openenergymonitor.org/emon/emonbase">Dogfennaeth</a>, <a href="https://shop.openenergymonitor.com/base-stations/" >Siop</a></p>
                <div style="clear:both;"></div>
        </div>
      </div>
      
      <div id="box">
        <div id="maintext">
        <h2>emoncms</h2>
        <p>Mae <a href="https://emoncms.org/">Emoncms.org</a> yn app-we ffynhonnell agored wedi ei greu fel rhan or prosiect i prosesu, storio a edrych ar data egni a amgylcheddol.</p>
       

       <img src="<?php echo $path; ?>Views/pages/images/emoncms.png" style="float:left; width: 400px; padding-right:20px"/>
       <img src="<?php echo $path; ?>Views/pages/images/report.png" style="float:left; width: 400px; padding-right:20px"/>
       <div style="clear:both;"></div>
        <p>Da ni hefyd yn datablygu app-we sydd yn cysylltu efo emoncms sydd yn gedru cael ei ddefnyddio i archiwilio perfformiad egni gwres adeiladau trwy asesiad SAP</p>
        
        
       <img src="<?php echo $path; ?>Views/pages/images/openbem.png" style="float:left; height: 300px; padding-left:60px; padding-right:140px"/>

       <img src="<?php echo $path; ?>Views/pages/images/dynamicmodel.png" style="float:left; height: 300px; padding-right:20px"/>
       
       <div style="clear:both;"></div><br>
        <p><b>emoncms: </b><a href="https://emoncms.org/">Dogfennaeth</a>, <a href="https://openenergymonitor.org/emon/openbem" >Modelu egni adeilad</a></p>
       
        
        </div>
      </div>
      
      <div id="box">
        <div id="maintext">
        <h2>Radio RFM12B 433Mhz, 868Mhz</h2>
        <p>Mae'r system yn defnyddio y radio dwy ffordd HopeRF (RFM12B) ar band ISM: 433Mhz (byd eang) neu (868Mhz Ewrop). Mae posib cael i fynu i 30 nod di-wifr ar un grwp, ac i fynu i 250 grwp. Mae ystod o i fynu i 300m llinell weld (hefo newid bach ir meddalwedd) ond ein profiad ni yw ei fod yn tebyg i ystod wifi - digon i fynd o gwmpas y ty.

        <p><b>rfm12b: </b><a href="https://openenergymonitor.org/emon/buildingblocks/rfm12b-wireless">Dogfennaeth</a></p>
        </div>
      </div>
      
      <div id="box">
        <div id="maintext">
        <a href="https://arduino.cc" ><img src="<?php echo $path; ?>Views/pages/images/arduino.jpeg" style="float:right; height:120px; padding-left:20px; padding-top:20px;"/></a>
        <a href="https://www.raspberrypi.org/"><img src="<?php echo $path; ?>Views/pages/images/raspilogo.png" style="float:right; height:120px; padding-left:20px; padding-top:20px"/></a>
        <h2>Platform Arduino a Raspberry Pi</h2>
        
        <p>Mae yr unedau emontx, emonglcd ac bwrdd derbynnydd y RFM12Pi yn defnyddio platform Arduino, sydd yn blatform poblogaidd gyda cymuned mawr ar y we. Mae hyn yn gwneud y system yn hyblyg iawn ac yn bosib ei gysylltu a chaledwedd arall sydd yn defnyddio Arduino efo chydig o waith codio. Mae'r EmonBase yn defynddio platform RaspberryPI sydd yn blatform poblogaidd ac estyniedig arall.</p>
        
                <div style="clear:both;"></div>
        </div>
      </div>
      
      <div id="box">
        <div id="maintext">
        <h2>Siop ar-lein OpenEnergyMonitor</h2>
        <p>Mae system OpenEnergyMonitor uchod ar gael trwy siop ar-lein openenergymonitor. Mae yn cael ei ddefnyddio gan unigolion, sefydliadau addysg a chwmniau a mae angen chydig o hyfedredd mewn meddalwedd a electroneg iw defnyddio ar hyn o bryd.</p>

        <p>Mae prisiau llawn ar gael ar siop openenergymonitor:</p>

        <p><a href="https://shop.openenergymonitor.com">shop.openenergymonitor.com</a></p>

        <p>Mae'r siop yn gael ei rhedeg gan Megni</p>
        </div>
      </div>
      
      <div id="box">
        <div id="maintext">
        <h2>Megni a OpenEnergyMonitor</h2>
        <p>Mae Megni yn cael ei rhedeg gan Glyn Hudson a Trystan Lea. Da nin byw yn Eryri, Gogledd Cymru. Mae y ddau ohonym yn sylfaenwyr a datblygwyr craidd prosiect OpenEnergyMonitor. Mae'r prosiect OpenEnergyMonitor yn endid ei hyn yn ar wahan i Megni, mae yn prosiect a chymuned monitro egni ffynhonnell agored ar y we gyda datblygwyr o llawer o wledydd drost y byd yn  cyfrannu a defnyddio y technoleg.</p>
        </div>
      </div>
      
      <div id="box">
        <div id="maintext">
          <img src="<?php echo $path; ?>Views/pages/images/build.jpg" style="float:right; width:350px; padding-left:20px; padding-top:20px"/>
          
          <h2>Ein gwerthoedd</h2>
          
          <p><b>Technoleg sydd yn helpu ni fyw o fewn terfynau ecolegol</b><br>
          Mae datblygiad y system ac ei defnydd yn cael ei arwain gan cymhelliant gennym i cyraedd, a gwneud y camau tuag at egni cynaladwy yn ein bywydau ein hun. Dechrewyd ni drwy optomeiddio ein defnydd o drydan a deallt cyfraniad trydan solar pv. Yn gynyddol mae datblygiad y system ar gyfer fesur perfformiad systemau gwres a ffabrig adeiladau.
          
          <p><b>Ffynhonnell agored</b><br>
          Da ni yn defnyddio technoleg ffynhonnell agored wedi datablygu fel rhan or prosiect ac yn adeiladu ar gwaith agored prosiectau arall. Da ni yn credu for technoleg ffynhonnell agored yn ffordd well o gwneud petha. Medrwch ddysgu mwy am dan hyn, sut mae'r technoleg yn gweithio a sut iw adeiladu, atgyweirio a gwella, ar wefan y prosiect: <a href="https://openenergymonitor.org">openenergymonitor.org</a></p>
          
          <div style="clear:both;"></div>
          
        
        </div>
      </div>
      <div id="footer">
        <div id="maintext"> 
          <p>Cysylltwch a ni, ac mi fydd ni yn hapus i ateb eich cwestiynau.</p>
          
          <h2><b>Ebost: </b>info@openenergymonitor.zendesk.com</h2>
          <h2><b>Ffon:</b> +44(0)1286 800870</h2>
          <p><b>Cyfeiriad:</b>
          OpenEnergyMonitor (Megni), Yr Hen Ysgol (Caban Cyf), Brynrefail, Caernarfon, Gwynedd, LL55 3NR, United Kingdom</p>
          <p>VAT Number: GB 152 7345 15</p>

        </div>
      </div>

      <div id="box">
        <div id="maintext">
          
          <h2>Eryri</h2>
          <img src="<?php echo $path; ?>Views/pages/images/O7UH.JPG" style="width:930px;"/>

          <p>Da nin byw yn Eryri, Gogledd Cymru wedi aros yma oherwydd y mynyddoedd, y cleimio ar beicio mynydd. Diolch ir we da nin gedru mwynhau datblygu technoleg ffynhonnell agored a redeg busnes technoleg o fan hyn hefyd.</p>
          
          <p><b>Blog cleimio Glyn: </b><a href="https://adventuresplusnorthwales.blogspot.co.uk/" >Anturieuthau + Gogledd Cymru</a></p>
          <p><b>Twitter: </b><a href="httpss://twitter.com/trystanlea" >@trystanlea</a>, <a href="httpss://twitter.com/glynhudson" >@glynhudson</a></p>
          <div style="clear:both;"></div>
          
        
        </div>
      </div>

      <!---
      <div id="box">
        <div id="maintext"> 
          <img src="<?php echo $path; ?>Views/pages/images/dailypostaward.jpg" style="width:150px; padding-top:20px"/>
        </div>
      </div>--->
